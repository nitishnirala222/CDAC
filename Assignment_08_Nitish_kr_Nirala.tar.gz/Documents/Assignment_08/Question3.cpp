#include<iostream>
#include<string>
using namespace std;

class Account
{
private:
char name[25];
int ac_no=1122334455,ifsc_code=12345,avail_bal=1000;

public:

void Withdraw()
{
int wd,a,ic;
cout<<"enter your name: ";
cin>>name;
cout<<"enter your Account_no: ";
cin>>a;
cout<<"enter your ifsc_code: ";
cin>>ic;
if(ac_no==a && ifsc_code==ic){
cout<<"enter amount to be withdraw: ";
cin>>wd;
avail_bal=avail_bal-wd;
cout<<"withdraw successfully"<<endl;
cout<<"_________________________________________________"<<endl;
}
else
{
cout<<"Either Account no. or ifsc code is wrong"<<endl;
}
}
void Deposit()
{
int dp,a,ic;
cout<<"enter your name: ";
cin>>name;
cout<<"enter your Account_no: ";
cin>>a;
cout<<"enter your ifsc_code: ";
cin>>ic;
if(ac_no==a && ifsc_code==ic){
cout<<"enter amount to be deposit: ";
cin>>dp;
avail_bal+=dp;
cout<<"Deposited Successfully"<<endl;
cout<<"_________________________________________________"<<endl;
}
else
cout<<"Either Account no. or ifsc code is wrong"<<endl;
}
void Balance_check()
{
int a,ic;
cout<<"enter your Account_no: ";
cin>>a;
cout<<"enter your ifsc_code: ";
cin>>ic;
if(ac_no==a && ifsc_code==ic){
cout<<"your available balance is: "<<avail_bal<<endl;
cout<<"_________________________________________________"<<endl;
}
else
cout<<"Either Account no. or ifsc code is wrong"<<endl;
}
};
int main()
{
int c;
Account a;
x:
cout<<"1. for Deposit Amount"<<endl;
cout<<"2. for Withdraw Amount"<<endl;
cout<<"3. for check balance"<<endl;
cout<<"4. for exit"<<endl;
cout<<"enter your choice: ";
cin>>c;
switch(c)
{
case 1:
a.Deposit();
break;
case 2:
a.Withdraw();
break;
case 3:
a.Balance_check();
break;
case 4:
exit(1);
break;
default:
cout<<"please select correct option";
}
goto x;
}
