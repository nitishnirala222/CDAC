#include<iostream>
#include<cstring>
using namespace std;

class Customer
{
public:
 Customer(char *Name,int cnum,float bal) //constructor
 {
strcpy(name,Name);
 c_num=cnum;
 ytd_balance=bal;
 }
 private:
char name[30];
int c_num;
float ytd_balance;
public:
friend void Person(Customer *cr);
};

class Account
{
public:
Account(char *ar,int ac_bal) //constructor
{
strcpy(acctcode,ar);
ac_balance=ac_bal;
}
private:
char acctcode[5];
float ac_balance;
public:
friend void ledger(Account *ac);
};
void Person(Customer *cr)
{
cout<<"customer's name: "<<cr->name<<endl;
cout<<"customer's c_num: "<<cr->c_num<<endl;
cout<<"customer's ytd_balance: "<<cr->ytd_balance<<endl;
}
void ledger(Account *ac)
{
cout<<"customer's acctcode: "<<ac->acctcode<<endl;
cout<<"customer's ac_balance: "<<ac->ac_balance<<endl;
}

int main()
{
char str[]="nitish";
char str2[]="cus44";
Customer c(str,12345,50000);
Account a(str2,60000);
Person(&c);
ledger(&a);
}
