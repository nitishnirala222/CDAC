#include<iostream>
using namespace std;

class Student
{
public:
char name[30],branch[30];
int reg_no,session;

};

void SetData(Student s[],int i)
{
cout<<"enter student's name: ";
cin>>s[i].name;
cout<<"enter student's Decipline: ";
cin>>s[i].branch;
cout<<"enter student's Registration_no: ";
cin>>s[i].reg_no;
cout<<"enter student's Session: ";
cin>>s[i].session;
}

void Display(Student st[],int n)
{
for(int i=1;i<=n;i++)
{
cout<<"student's name: "<<st[i].name<<endl;
cout<<"student's decipline: "<<st[i].branch<<endl;
cout<<"student's registration_no: "<<st[i].reg_no<<endl;
cout<<"student's session: "<<st[i].session<<endl;
cout<<"_____________________________________________"<<endl;
}
}
int main()
{
Student st[10];
int count=0;
char ch;
x:
++count;
SetData(st,count);
cout<<"Do you want to continue?[y/n]: ";
cin>>ch;
if(ch=='y'|ch=='Y')
goto x;
else
cout<<"____________student's summary_____________"<<endl;
Display(st,count);
exit(1);
}
