#include<stdio.h>

int main()
{
int x,y,r,s=0;
printf("enter a number to check armstrong or not: ");
scanf("%d",&x);
y=x;
while(x>0)
{
r=x%10;
s+=r*r*r;
x=x/10;
}
if(y==s)
printf("The number %d is an armstrong number",y);
else
printf("The number %d is not an armstrong number",y);
}
