#include<stdio.h>

int main()
{
int n,i=0,first=0,sec=1,next;
printf("enter a number upto want to print fibbonacci series: ");
scanf("%d",&n);
printf("%d %d ",first,sec);
while(i<=n)
{
next=first+sec;
first=sec;
sec=next;
i=next;
printf("%d ",next);
}
}
