#include<stdio.h>

int main()
{
int n,s=1;
printf("enter a number upto want to print: ");
scanf("%d",&n);
for(int i=0;i<=n;i=i+2)
{
s+=i;
printf("%d ",s);
}
}
