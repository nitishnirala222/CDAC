#include<stdio.h>

int main()
{
int n,count=0;
printf("enter a number: ");
scanf("%d",&n);
for(int i=2;i<=n/2;i++)
{
if(n%i==0)
count++;
}
if(count==0)
printf("The number %d is a prime number",n);
else 
printf("The number %d is not a prime number",n);
}
