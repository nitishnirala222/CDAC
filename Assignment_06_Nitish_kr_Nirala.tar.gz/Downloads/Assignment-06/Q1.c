#include<stdio.h>

int main()
{
int a[5]={10,20,30,40,50};
int *p=a,*q=*(&a+1)-1;
printf("\n*p++: %d",*p++); //10, p=0
printf("\n*++p: %d",*++p); //30, p=2
printf("\n(*p)++: %d",(*p)++); //30, p=2
printf("\n++(*p): %d",++(*p)); //32, p=2
printf("\n++*p: %d",++*p); //33, p=2
printf("\n*(p++): %d",*(p++)); //33, p=2
printf("\n*(++p): %d",*(++p)); //50, p=4
printf("\n*q--: %d",*q--); //50, q=4
printf("\n*--q: %d",*--q); //33, q=2
printf("\n--(*q): %d",--(*q)); //32, q=2
printf("\n--*q: %d",--*q); //31, q=2
printf("\n(*q)--: %d",(*q)--); //31, q=2
printf("\n*(q--): %d",*(q--)); //30, q=2
printf("\n*(--q): %d",*(--q)); //10, q=0
}
