#include<stdio.h>

int swap(int *p,int *q)
{
int t;
t=*p;
*p=*q;
*q=t;
}
int main()
{
int a,b;
printf("enter 1st number: ");
scanf("%d",&a);
printf("enter 2nd number: ");
scanf("%d",&b);
printf("Before swapping a= %d and b= %d",a,b);
swap(&a,&b);
printf("\nAfter swapping a= %d and b= %d",a,b);
}
