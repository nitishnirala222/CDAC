#include<stdio.h>

int test(int *x)
{
int y=*x**x;
return y;
}
int main()
{
int p=10;
int x=test(&p);
printf("%d",x);

}
