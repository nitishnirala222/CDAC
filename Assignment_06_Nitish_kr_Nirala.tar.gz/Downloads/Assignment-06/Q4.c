#include<stdio.h>
int Sum(int n,int ar[])
{
int s=0;
for(int i=0;i<n;i++)
s+=ar[i];
return s;
}
int main()
{
int x;
printf("how many numbers you want to find sum: ");
scanf("%d",&x);
int arr[x];
printf("enter %d numbers respectively: \n",x);
for(int i=0;i<x;i++)
scanf("%d",&arr[i]);
printf("The sum of %d numbers is %d",x,Sum(x,arr));
}
