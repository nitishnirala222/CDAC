#include<stdio.h>

float main()
{
float bs,da,hra,gross_sal,pf;
printf("Enter Ramesh's basic salary: ");
scanf("%f",&bs);
 da=bs*40/100;
 hra=bs*20/100;
 gross_sal=bs+da+hra;
 pf=gross_sal*10/100;
printf("\nNet Salary is: %.2f",gross_sal);
printf("\nPF is: %.2f",pf);

}
