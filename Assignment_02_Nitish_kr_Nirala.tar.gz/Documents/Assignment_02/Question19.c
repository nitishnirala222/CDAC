#include<stdio.h>

int main()
{
int cid,cons;
float c,rs;
printf("enter CID: ");
scanf("%d",&cid);
printf("enter unit consumed by the customer: ");
scanf("%d",&cons);
if(cons<=199)
c=cons*4.2;
else if(200<cons<400)
c=cons*5.5;
else if(400<cons<600)
c=cons*6.8;
else
c=cons*8;

if(c>800)
rs=c+c*18/100;
else
rs=c;
printf("The total amount to pay to the customer is %.2f",rs);
}
