#include<stdio.h>

int main()
{
printf("Choose Option");
printf("\n1. for Sum");
printf("\n2. for Subtraction");
printf("\n3. for Multiplication");
printf("\n4. for Division");
int n,a,b;
printf("\nenter your choice: ");
scanf("%d",&n);
printf("enter 1st number: ");
scanf("%d",&a);
printf("enter 2nd number: ");
scanf("%d",&b);

switch(n)
{
case 1:
printf("sum of two number is: %d",a+b);
break;
case 2:
printf("subtraction of two number is: %d",a-b);
break;
case 3:
printf("multiplication of two number is: %d",a*b);
break;
case 4:
printf("Division of two number is: %d",a/b);
break;
default:
printf("Choose Correct option");
}
}
