#include<stdio.h>

int main()
{
int sec,m,h,s;
printf("enter a number of seconds: ");
scanf("%d",&sec);
h=sec/3600;

m=(sec%3600)/60;

s=(sec%3600)%60;

printf("hours: %d, minutes: %d, seconds: %d",h,m,s);
}
