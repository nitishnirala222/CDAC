#include<stdio.h>

int main()
{
int a,b;
printf("enter 1st number: ");
scanf("%d",&a);
printf("enter 2nd number: ");
scanf("%d",&b);
printf("Before Swapping a= %d and b= %d",a,b);
a=a+b;
b=a-b;
a=a-b;
printf("\nAfter Swapping a= %d and b= %d",a,b);

}
