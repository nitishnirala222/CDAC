#include<stdio.h>

int main()
{
printf("\nHello World\n");
printf("\tHello World\n");
printf("\rHello World\n");
printf("\\.Hello World");

}
