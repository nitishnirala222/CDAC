#include<stdio.h>

int main()
{
printf("Choose Option");
printf("\n1. for Sunday");
printf("\n2. for Monday");
printf("\n3. for Tuesday");
printf("\n4. for Wednesday");
printf("\n5. for Thursday");
printf("\n6. for Friday");
printf("\n7. for Saturday");
int n;
printf("\nenter your choice: ");
scanf("%d",&n);

switch(n)
{
case 1:
printf("Sunday");
break;
case 2:
printf("Monday");
break;
case 3:
printf("Tuesday");
break;
case 4:
printf("Wednesday");
break;
case 5:
printf("Thursday");
break;
case 6:
printf("Friday");
break;
case 7:
printf("Saturday");
break;
default:
printf("Choose Correct option");
}
}
