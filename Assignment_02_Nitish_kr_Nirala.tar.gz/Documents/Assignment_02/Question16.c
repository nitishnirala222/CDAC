#include<stdio.h>
#include<string.h>
int main()
{
printf("Choose Option");
printf("\n1. for january");
printf("\n2. for ferbuary");
printf("\n3. for march");
printf("\n4. for april");
printf("\n5. for june");
printf("\n6. for july");
printf("\n7. for august");
printf("\n8. for ferbuary");
printf("\n9. for march");
printf("\n10. for april");
printf("\n11. for june");
printf("\n12. for july");
int n;
printf("\nenter your choice: ");
scanf("%d",&n);
switch(n)
{
case 1:
printf("no. of days: 31");
break;
case 2:
printf("no. of days: 28 or 29");
break;
case 3:
printf("no. of days: 31");
break;
case 4:
printf("no. of days: 30");
break;
case 5:
printf("no. of days: 31");
break;
case 6:
printf("no. of days: 30");
break;
case 7:
printf("no. of days: 31");
break;
case 8:
printf("no. of days: 31");
break;
case 9:
printf("no. of days: 30");
break;
case 10:
printf("no. of days: 31");
break;
case 11:
printf("no. of days: 30");
break;
case 12:
printf("no. of days: 31");
break;
default:
printf("invalid choice");
}
}
