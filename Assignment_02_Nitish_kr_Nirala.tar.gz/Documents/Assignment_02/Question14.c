#include<stdio.h>

int main()
{
char c;
printf("enter a character: ");
scanf("%c",&c);
if((c>='a' && c<='z') ||(c>='A' && c<='Z'))
printf("entered character is alphabet");
else if(c>='0' && c<='9')
printf("entered character is digit");
else 
printf("entered character is special symbol");
}
