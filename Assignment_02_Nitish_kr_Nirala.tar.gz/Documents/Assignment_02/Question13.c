#include<stdio.h>

int main()
{
int h,m,p,c,e;
printf("Enter mark's of Hindi: ");
scanf("%d",&h);
printf("Enter mark's of Math: ");
scanf("%d",&m);
printf("Enter mark's of Physics: ");
scanf("%d",&p);
printf("Enter mark's of Chemistry: ");
scanf("%d",&c);
printf("Enter mark's of English: ");
scanf("%d",&e);

int total=h+m+p+c+e;
float avg=total/5;
if(avg>=90)
printf("Grade: A+");
else if(avg>=80 && avg<90)
printf("Grade: A");
else if(avg>=70 && avg<80)
printf("Grade: B+");
else if(avg>=60 && avg<70)
printf("Grade: B");
else if(avg>=50 && avg<60)
printf("Grade: C");
else
printf("Grade: fail");
}
