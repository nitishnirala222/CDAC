#include<stdio.h>
#define f(x) a*x*x+b*x+c
int main()
{
int a,b,c,x,e;
printf("enter 1st number: ");
scanf("%d",&a);
printf("enter 2nd number: ");
scanf("%d",&b);
printf("enter 3rd number: ");
scanf("%d",&c);
printf("enter 4th number: ");
scanf("%d",&x);

printf("The value of f(x) is: %d",f(x));

}
