#include<stdio.h>

int main()
{
int bp;
printf("enter base price: ");
scanf("%d",&bp);
float total_price=bp+bp*12/100;
printf("Total price is: %.2f",total_price);
}
