#include<stdio.h>

float main()
{
float bs;
printf("Enter Ramesh's basic salary: ");
scanf("%d",&bs);
float da=bs*40/100;
float hra=bs*20/100;
float gross_sal=ba+da+hra;
printf("Gross Salary is: %.2f",gross_sal);
}
