#include<stdio.h>

int main()
{
int n,rem,sum=0;
printf("enter a number: ");
scanf("%d",&n);
int num=n;
while(n>0)
{
rem=n%10;
sum+=rem;
n=n/10;
}
printf("The sum of digits of %d is %d",num,sum);
}
