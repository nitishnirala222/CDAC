#include<stdio.h>

int main()
{
int h,m,p,c,e;
printf("Enter mark's of Hindi: ");
scanf("%d",&h);
printf("Enter mark's of Math: ");
scanf("%d",&m);
printf("Enter mark's of Physics: ");
scanf("%d",&p);
printf("Enter mark's of Chemistry: ");
scanf("%d",&c);
printf("Enter mark's of English: ");
scanf("%d",&e);

int total=h+m+p+c+e;
float avg=total/5;
printf("Total obtained marks is: %d",total);
printf("\nAvg marks is: %.2f",avg);
}
