#include<stdio.h>
int main()
{
int a,b;
printf("enter 1st number: ");
scanf("%d",&a);
printf("enter 2nd number: ");
scanf("%d",&b);
printf("Before swapping a= %d and b=%d",a,b);

int temp;
temp=a;
a=b;
b=temp;
printf("After swapping a= %d and b=%d",a,b);
}
