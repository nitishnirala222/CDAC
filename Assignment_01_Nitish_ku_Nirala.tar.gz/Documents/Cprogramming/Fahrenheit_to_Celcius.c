#include<stdio.h>

int main()
{
float f;
printf("enter temperature in fahrenheit: ");
scanf("%f",&f);

float celcius= (f-32)*5/9;
printf("Temperature in celcius is %.2f",celcius);
}
