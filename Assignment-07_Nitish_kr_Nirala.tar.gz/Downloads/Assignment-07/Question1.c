
#include<stdio.h>
#include<string.h>

void main()
{
char str1[]="here first name";
char str2[]="here last name";
char ss[20];
strcpy(ss,str1);
int len=strlen(str1);
printf("The length of string is %d",len);
printf("\nThe concatenation of %s and %s is: %s",ss,str2,strcat(str1,str2));
int q=strcmp(ss,str2);
if(q==0)
printf("\nboth the strings are equal");
else
printf("\nboth the strings are not equal");

}
