#include<stdio.h>

int Perfect_no(int n)
{
int s=0,x;
for(int i=1;i<=n;i++)
if(n%i==0)
s+=i;
x=s/2;
if(n==x)
printf("The number %d is a perfect number",n);
else
printf("The number %d is not a perfect number",n);
}
int main()
{
int a;
printf("enter a number to check perfect number: ");
scanf("%d",&a);
Perfect_no(a);
}
