#include<stdio.h>
int IsPrime(int n)
{
int count=0;
for(int i=1;i<n/2;i++){
if(n%i==0)
count++;
}
if(count==1)
printf("The number %d is a prime number",n);
else
printf("The number %d is not a prime number",n);
}

int main()
{
int x;
printf("enter a number to check prime number: ");
scanf("%d",&x);
IsPrime(x);
}
