#include<stdio.h>

int Armstrong(int n)
{
int r,p,sum=0;
p=n;
while(n>0){
r=n%10;
sum+=r*r*r;
n=n/10;
}
if(p==sum)
printf("The number %d is an armstrong number",p);
else
printf("The number %d is not an armstrong number",p);
}
int main()
{
int x;
printf("enter a number to check armstrong number: ");
scanf("%d",&x);
Armstrong(x);
}
