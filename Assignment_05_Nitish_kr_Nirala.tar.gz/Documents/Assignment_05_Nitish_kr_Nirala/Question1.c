#include<stdio.h>

int Sum(int ar[],int x)
{
int sum=0;
for(int j=0;j<x;j++)
sum+=ar[j];
printf("The sum of %d numbers is %d",x,sum);
return sum;
}
int Average(int w,int y)
{
int avg1=w/y;
printf("\nThe average of %d numbers is %d",y,avg1);
}
int main()
{
int n,avg;
printf("How many numbers you want to enter to find sum and average: ");
scanf("%d",&n);
int arr[n];
printf("enter %d numbers: ",n);
for(int i=0;i<n;i++)
scanf("%d",&arr[i]);
avg=Sum(arr,n);
Average(avg,n);

}
