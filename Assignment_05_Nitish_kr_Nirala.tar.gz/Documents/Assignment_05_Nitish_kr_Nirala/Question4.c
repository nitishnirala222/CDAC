#include<stdio.h>

int Fibbonacci(int n)
{
if(n==0 || n==1)
return n;
else 
return Fibbonacci(n-2)+Fibbonacci(n-1);
}

int main()
{
int x;
printf("enter the number of terms to print fabbonacci series: ");
scanf("%d",&x);
printf("The Fabbonacci Series is \n");
for(int i=0;i<x;i++)
printf("%d ",Fibbonacci(i));
}
